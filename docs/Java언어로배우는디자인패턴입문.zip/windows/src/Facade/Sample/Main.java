import pagemaker.PageMaker;

public class Main {
    public static void main(String[] args) {
        PageMaker.makeWelcomePage("a1@youngjin.com", "welcome.html");
    }
}
