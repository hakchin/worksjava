package framework;

public abstract class Product {
    public abstract void use();
}
