public interface Aggregate {
    public abstract Iterator iterator();
}
