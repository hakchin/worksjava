package language;

public interface Executor {
    public abstract void execute() throws ExecuteException;
}
