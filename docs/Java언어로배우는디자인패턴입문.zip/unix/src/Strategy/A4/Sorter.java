import java.lang.Comparable;
import java.util.Comparator;

public interface Sorter {
    public abstract void sort(Comparable[] data);
}
